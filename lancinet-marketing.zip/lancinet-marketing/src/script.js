// Menu mobile : ouverture/fermeture
document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".nav");

  navToggle.addEventListener("click", function () {
    nav.classList.toggle("nav-open");
  });
});
// Animation d’apparition avec Intersection Observer
const fadeElements = document.querySelectorAll('.fade-in');

const observer = new IntersectionObserver((entries, observer) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('appear');
      observer.unobserve(entry.target);
    }
  });
}, {
  threshold: 0.1,
});

fadeElements.forEach(el => observer.observe(el));
// Envoi intelligent du formulaire de contact
document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("contact-form");
  const message = document.getElementById("form-message");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const formData = new FormData(form);

    fetch("https://formspree.io/f/xyzabcde", { // Remplace avec ton propre lien Formspree
      method: "POST",
      headers: {
        'Accept': 'application/json'
      },
      body: formData
    })
    .then(response => {
      if (response.ok) {
        message.textContent = "Message envoyé avec succès ! ✅";
        message.style.color = "green";
        form.reset();
      } else {
        message.textContent = "Une erreur s’est produite. Réessayez.";
        message.style.color = "red";
      }
    })
    .catch(() => {
      message.textContent = "Erreur de connexion. Vérifie ta connexion internet.";
      message.style.color = "red";
    });
  });
});